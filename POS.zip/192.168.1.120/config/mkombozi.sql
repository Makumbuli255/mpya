-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 23, 2024 at 08:32 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mkombozi`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `name` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `password` varchar(191) NOT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `is_ban` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0=not_ban,1=ban',
  `created_at` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `password`, `phone`, `is_ban`, `created_at`) VALUES
(2, 'Emanuel Bwana', 'ebwana@gmail.com', '$2y$10$KTUl7T83C4T7OH6QNC9iWuSn.Z/JUg.GZlrylLpcXljPl3A4jXKv6', '123456789', 0, '2024-08-01'),
(7, 'Shabani Twahili', 'shabanitwahili0@gmail.com', '$2y$10$ZlLJfjWKh1PYcVJsE/PpC.cLuWB9EFbqrW/JwOu9KyGSEdLtEdo96', '0677421358', 0, '2024-08-01');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(191) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0=visible,1=hidden'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`, `status`) VALUES
(1, 'Tablets', 'This is Tablet Area', 0),
(2, 'Capsules', 'This is Capsule area', 0),
(3, 'Injection', 'This is Injection area', 0);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `name` varchar(191) NOT NULL,
  `email` varchar(191) DEFAULT NULL,
  `location` varchar(191) NOT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT 0 COMMENT '0=visible,1=hidden',
  `created_at` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `name`, `email`, `location`, `phone`, `status`, `created_at`) VALUES
(1, 'Fatuma Hasani Ungula', 'fatuma@gmail.com', 'Mndumbwe', '0677123123', 0, '2024-08-02'),
(3, 'test test2', '', 'Mtwara', '123123123', 0, '2024-08-05'),
(4, 'Test3 Test', 'test@gmail.com', 'Kilwa', '07777777', 0, '2024-08-05'),
(5, 'Mteja Mpya', 'mteja@gmail.com', 'Pemba', '0788998778', 0, '2024-08-23');

-- --------------------------------------------------------

--
-- Table structure for table `medicine`
--

CREATE TABLE `medicine` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `name` varchar(191) NOT NULL,
  `batch` varchar(100) NOT NULL,
  `mfg` date NOT NULL,
  `exp` date NOT NULL,
  `quantity` int(11) NOT NULL,
  `buy` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0=visible,1=hidden',
  `created_at` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `medicine`
--

INSERT INTO `medicine` (`id`, `category_id`, `name`, `batch`, `mfg`, `exp`, `quantity`, `buy`, `price`, `status`, `created_at`) VALUES
(1, 1, 'Paracetamol 500mg', 'P234', '2020-08-02', '2024-08-03', 103, 70, 100, 0, '2024-08-02'),
(3, 2, 'Diclofenac', 'DDD', '2024-07-30', '2024-08-06', 0, 23, 50, 1, '2024-08-02');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `tracking_no` varchar(100) NOT NULL,
  `invoice_no` varchar(100) NOT NULL,
  `total_amount` varchar(100) NOT NULL,
  `order_date` date NOT NULL,
  `order_status` varchar(100) DEFAULT NULL,
  `payment_mode` varchar(100) NOT NULL COMMENT 'cash, online',
  `order_placed_by_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `customer_id`, `tracking_no`, `invoice_no`, `total_amount`, `order_date`, `order_status`, `payment_mode`, `order_placed_by_id`) VALUES
(1, 3, '26780', 'INV-MSP195517', '1300', '2024-08-05', 'booked', 'Cash Payment', 7),
(2, 3, '44947', 'INV-MSP145171', '450', '2024-08-05', 'booked', 'Cash Payment', 7),
(3, 3, '99714', 'INV-MSP368099', '1200', '2024-08-05', 'ordered', 'Cash Payment', 7),
(4, 1, '12430', 'INV-MSP245535', '600', '2024-08-05', 'ordered', 'Online Payment', 7),
(5, 3, '65780', 'INV-MSP791201', '600', '2024-08-19', 'ordered', 'Cash Payment', 7),
(6, 1, '97242', 'INV-MSP900249', '400', '2024-08-23', 'ordered', 'Online Payment', 7),
(7, 5, '18303', 'INV-MSP301313', '1600', '2024-08-23', 'ordered', 'Cash Payment', 7),
(8, 5, '28028', 'INV-MSP412656', '500', '2024-08-23', 'ordered', 'Online Payment', 7),
(9, 4, '45641', 'INV-MSP641142', '500', '2024-08-23', 'ordered', 'Online Payment', 7),
(10, 5, '98947', 'INV-MSP354485', '500', '2024-08-23', 'ordered', 'Online Payment', 7),
(11, 1, '66709', 'INV-MSP982463', '2500', '2024-08-23', 'ordered', 'Online Payment', 7);

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `medicine_id` int(11) NOT NULL,
  `price` varchar(100) NOT NULL,
  `quantity` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `medicine_id`, `price`, `quantity`) VALUES
(1, 1, 1, '100', '9'),
(2, 1, 3, '50', '8'),
(3, 2, 1, '100', '4'),
(4, 2, 3, '50', '1'),
(5, 3, 1, '100', '12'),
(6, 4, 1, '100', '6'),
(7, 5, 1, '100', '6'),
(8, 6, 1, '100', '4'),
(9, 7, 1, '100', '16'),
(10, 8, 1, '100', '5'),
(11, 9, 1, '100', '5'),
(12, 10, 1, '100', '5'),
(13, 11, 1, '100', '25');

-- --------------------------------------------------------

--
-- Table structure for table `setting`
--

CREATE TABLE `setting` (
  `id` int(11) NOT NULL,
  `names` varchar(121) NOT NULL,
  `phone` varchar(23) NOT NULL,
  `po_address` varchar(23) NOT NULL,
  `ph_address` varchar(23) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `setting`
--

INSERT INTO `setting` (`id`, `names`, `phone`, `po_address`, `ph_address`) VALUES
(8, 'IT STATIOMERY', '0677421358', 'P.o Box 0101', 'Home');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `medicine`
--
ALTER TABLE `medicine`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `setting`
--
ALTER TABLE `setting`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `medicine`
--
ALTER TABLE `medicine`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `setting`
--
ALTER TABLE `setting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
