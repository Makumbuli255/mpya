<?php include ('includes/header.php'); ?>

<div class="container-fluid px-4">
	<div class="card mt-4 shadow-sm">
		<div class="card-header">
			<h4 class="mb-0">Edit Settings
				<a href="setting.php" class="btn btn-danger float-end">Back</a></h4>
		</div>
		<div class="card-body">

			<?php alertMessage(); ?>

			<form action="code.php" method="POST">

				<?php 
				$parmValue = checkParamId('id');
				if(!is_numeric($parmValue)){
					echo '<h5>'.$parmValue.'</h5>';
					return false;

				}

				$setting = getById('setting',$parmValue);
				if($setting['status'] ==200)
				{

				 ?>

				 <input type="hidden" value="<?= $setting['data']['id']; ?>" name="settingId">



				<div class="row">
					<div class="col-md-6 mb-3">
						<label for="">Company Name <span class="text-danger">*</span></label>
						<input type="text" name="names" value="<?= $setting['data']['names']; ?>" required="" class="form-control" />
					</div>
					<div class="col-md-6 mb-3">
						<label for="">Phone Number <span class="text-danger">*</span></label>
						<input type="text" name="phone" value="<?= $setting['data']['phone']; ?>" required="" class="form-control" />
					</div>
					<div class="col-md-6 mb-3">
						<label for="">Postal Address <span class="text-danger">*</span></label>
						<input type="text" name="po_address" value="<?= $setting['data']['po_address']; ?>" required="" class="form-control" />
					</div>
					<div class="col-md-6 mb-3">
						<label for="">Physical Address <span class="text-danger">*</span></label>
						<input type="text" name="ph_address" value="<?= $setting['data']['ph_address']; ?>" required="" class="form-control" />
					</div>


					<div class="col-md-6 mb-3 text-end">
						<br/>
						<button type="submit" name="updateSetting" class="btn btn-primary">Update</button>
					</div>
					
				</div>
				<?php
			    }
			    else{
			    	echo '<h5>'.$category['message'].'</h5>';

			}
			?>
				
			</form>

			
		</div>
	</div>
		
</div>

<?php include ('includes/footer.php'); ?>