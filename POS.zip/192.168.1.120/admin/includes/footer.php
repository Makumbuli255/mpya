                </main>
                
                <footer class="py-3 bg-light mt-auto">
                    <div class="container-fluid px-3">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Coded By: Shabani Twahili &copy;  2024</div>
                            <div>
                                <a href="#">+255 677 421 358</a>
                                &middot;
                                <a href="#">shabanitwahili0@gmail.com</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
<script src="assets/js/jquery-3.7.1.min.js"></script>


        <script src="assets/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>

        <script src="assets/js/scripts.js"></script>
       

        <script src="assets/js/Chart.min.js"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="assets/js/simple-datatables.min.js"></script>
        <script src="assets/js/datatables-simple-demo.js"></script>
        <script src="assets/js/select2.min.js"></script>
        <script>
            $(document.ready(function(){
                $('.mySelect2').select2();
            }));
        </script>
        <script src="assets/js/html2canvas.min.js"></script>
        <script src="assets/js/jspdf.umd.min.js"></script>
        <script src="assets/js/sweetalert.min.js"></script>
        <script src="assets/js/alertify.min.js"></script>
        <script src="assets/js/custom.js">
             
         </script>
    </body>
</html>
