<?php 
require '../config/function.php';
require 'authentication.php';
 ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>STMIT</title>
        <link href="assets/css/style.min.css" rel="stylesheet" />
        <link href="assets/css/styles.css" rel="stylesheet" />
        <script src="assets/js/all.js" crossorigin="anonymous"></script>
        <link href="assets/css/select2.min.css" rel="stylesheet" />
        <link rel="stylesheet" href="assets/css/alertify.min.css"/>
        <link rel="stylesheet" href="assets/css/default.min.css"/>
        <link rel="stylesheet" type="text/css" href="assets/css/bootstrap-icons.css">
    </head>
    <body class="sb-nav-fixed">

        <?php include('navbar.php') ?>

        <div id="layoutSidenav">

            <?php include ('sidebar.php'); ?>

                <div id="layoutSidenav_content">

                    <main>

        