<?php 

require '../config/function.php';

$paraResultId = checkParamId('id');

if(is_numeric($paraResultId)){

	$medicineId = validate($paraResultId);

	$medicine = getById('medicine',$medicineId);
	if($medicine['status'] == 200)
	{
		$medicine = delete('medicine', $medicineId);
		if($response)
		{
			redirect('medicine.php','Medicine Deleted Successfully !!!');
		}
		else
		{
			redirect('Medicine.php','Something Went Wrong !!!');
		}

	}
	else
	{
	redirect('medicine.php',$medicine['message']);	
	}


}else{
	http_redirect('medicine.php','Something Went Wrong !!!');

}

 ?>