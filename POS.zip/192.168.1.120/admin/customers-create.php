<?php include ('includes/header.php'); ?>

<div class="container-fluid px-4">
	<div class="card mt-4 shadow-sm">
		<div class="card-header">
			<h4 class="mb-0">Add Customer
				<a href="customers.php" class="btn btn-danger float-end">Back</a></h4>
		</div>
		<div class="card-body">
			<?php alertMessage(); ?>
			<form action="code.php" method="POST">
				<div class="row">
					<div class="col-md-12 mb-3">
						<label for="">Customer Name <span class="text-danger">*</span></label>
						<input type="text" name="name" required="" class="form-control" />
					</div>
					<div class="col-md-5 mb-3">
						<label for="">Customer Email <span class="text-danger">*</span></label>
						<input type="email" name="email" required=""  class="form-control" />
					</div>
					<div class="col-md-4 mb-3">
						<label for="">Location <span class="text-danger">*</span></label>
						<input type="text" name="location" required="" class="form-control" />
					</div>
					<div class="col-md-3 mb-3">
						<label for="">Phone Number <span class="text-danger">*</span></label>
						<input type="text" name="phone" required="" class="form-control" />
					</div>
					<div class="col-md-3 mb-3">
						<label for="">Is Ban</label>
						<br/>
						<input type="checkbox" name="is_ban" style="width: 20px; height: 20px;" />
					</div>
					<div class="col-md-9 mb-3 text-end">
						<br/>
						<button type="submit" name="saveCustomer" class="btn btn-primary">Save</button>
					</div>
					
				</div>
				
			</form>

			
		</div>
	</div>
		
</div>

<?php include ('includes/footer.php'); ?>