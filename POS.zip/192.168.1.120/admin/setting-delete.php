<?php 

require '../config/function.php';

$paraResultId = checkParamId('id');

if(is_numeric($paraResultId)){

	$settingId = validate($paraResultId);

	$setting = getById('setting',$settingId);
	if($setting['status'] == 200)
	{
		$response = delete('setting', $settingId);
		if($response)
		{
			redirect('setting.php','Info Deleted Successfully !!!');
		}
		else
		{
			redirect('setting.php','Something Went Wrong !!!');
		}

	}
	else
	{
	redirect('setting.php',$setting['message']);	
	}


}else{
	http_redirect('setting.php','Something Went Wrong !!!');

}

 ?>