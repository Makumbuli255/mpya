<?php 
include ('../config/function.php');

$paramResult = checkParamId('index');
if(is_numeric($paramResult)){

	$indexValue = validate($paramResult);

	if(isset($_SESSION['medicineItems']) && isset($_SESSION['medicineItemIds'])){

		unset($_SESSION['medicineItems'][$indexValue]);
		unset($_SESSION['medicineItemIds'][$indexValue]);

		redirect('order-create.php', 'Item Removed');

	}else{

		redirect('order-create.php', 'There is no item');

	}

 }else{
 	redirect('order-create.php', 'param not numeric');
 }

 ?>
