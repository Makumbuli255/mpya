$(function () {
	// body...

	var set_number = function () {
		// body...
		var table_len = $('#data_table tbody tr').length+1;

		$('#no').val(table_len);
	}

	set_number();

	$('#add_data').click(function () {
		// body...
        var no = $('#no').val();
		var medicine_name = $('#medicine_name').val();
		var batch = $('#batch').val();
		var mfg = $('#mfg').val();
		var exp = $('#exp').val();
		var qty2 = $('#qty2').val();
		var total = $('#total').val();

		$('#data_table tbody:last-child').append(

			'<tr>'+
			     '<td>'+no+'</td>'+
			     '<td>'+medicine_name+'</td>'+
			     '<td>'+batch+'</td>'+
			     '<td>'+mfg+'</td>'+
			     '<td>'+exp+'</td>'+
			     '<td>'+qty2+'</td>'+
			     '<td>'+total+'</td>'+
			'</tr>'


			);

		// clear input data

		$('#no').val('');
		$('#medicine_name').val('');
		$('#batch').val('');
		$('#mfg').val('');
		$('#exp').val('');
		$('#qty2').val('');
		$('#total').val('');

		set_number();

	});



	$('#add_customer').click(function () {
		// body...
		var customer_name = $('#customer_name').val();
		var address = $('#address').val();
		var phone = $('#phone').val();

		$('#data_table1 tbody:last-child').append(

			'<tr>'+
			     '<td>'+customer_name+'</td>'+
			     '<td>'+address+'</td>'+
			     '<td>'+phone+'</td>'+
			'</tr>'


			);

		// clear input data

		$('#customer_name').val('');
		$('#address').val('');
		$('#phone').val('');

	});


});


$(function () {
	// body...

	$('#save').click(function () {
		// body...

		var table_data = [];
		var table_data1 = [];

		$('#data_table tr').each(function (row,tr) {
			// body...

            if ($(tr).find('td:eq(0)').text() == "") {


            }else{
				var sub = {

				'no' : $(tr).find('td:eq(0)').text(),
				'medicine_name' : $(tr).find('td:eq(1)').text(),
				'batch' : $(tr).find('td:eq(2)').text(),
				'mfg' : $(tr).find('td:eq(3)').text(),
				'exp' : $(tr).find('td:eq(4)').text(),
				'qty2' : $(tr).find('td:eq(5)').text(),
				'total' : $(tr).find('td:eq(6)').text()



			};

			table_data.push(sub);
		};


			});

				$('#data_table1 tr').each(function (row,tr) {
			// body...

			if ($(tr).find('td:eq(0)').text() == "") {


            }else{


				var sub1 = {

				'customer_name' : $(tr).find('td:eq(0)').text(),
				'address' : $(tr).find('td:eq(1)').text(),
				'phone' : $(tr).find('td:eq(2)').text()



			};

			table_data1.push(sub1);

		}


			});

        



			
		});
		
	});


