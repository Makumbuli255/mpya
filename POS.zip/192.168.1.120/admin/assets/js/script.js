function validateForm() {
  // body...
  var medicine_name = document.getElementById('medicine_name').value;
  var batch = document.getElementById('batch').value;
  var mfg = document.getElementById('mfg').value;
  var exp = document.getElementById('exp').value;
  var qty2 = document.getElementById('qty2').value;
  var total = document.getElementById('total').value;

  if (medicine_name == "") {
    alert("Required");
    return false;
  }

  if (batch == "") {
    alert("Required");
    return false;
  }

  if (mfg == "") {
    alert("Required");
    return false;
  }

  if (exp == "") {
    alert("Required");
    return false;
  }

  if (qty2 < 1) {
    alert("Out of Stock");
    return false;
  }

  else if (total == "") {
    alert("Required");
    return false;
  }

  return true;


}

function showData() {
  // body...
  var peopleList;
  if (localStorage.getItem("peopleList") == null) {
    peopleList = [];
  }
  else{
    peopleList = JSON.parse(localStorage.getItem("peopleList"))
  }

  var html = "";

  peopleList.forEach(function (element, index) {
    // body...
    html += "<tr>";
    html += "<td>" + element.medicine_name + "</td>";
    html += "<td>" + element.medicine_name + "</td>";
    html += "<td>" + element.batchNo + "</td>";
    html += "<td>" + element.mfg + "</td>";
    html += "<td>" + element.exp + "</td>";
    html += "<td>" + element.qty2 + "</td>";
    html += "<td>" + element.total + "</td>";
        html += "</tr>";

  });

  document.querySelector("#crudTable tbody").innerHTML = html;
}

document.onload = showData();

function AddData() {
  // body...
  if (validateForm() == true) {
    
    var medicine_name = document.getElementById("medicine_name").value;
    var batchNo = document.getElementById("batchNo").value;
    var mfg = document.getElementById("mfg").value;
    var exp = document.getElementById("exp").value;
    var qty2 = document.getElementById("qty2").value;
    var total = document.getElementById("total").value;


  var peopleList;
  if (localStorage.getItem("peopleList") == null) {
    peopleList = [];
  }
  else{
    peopleList = JSON.parse(localStorage.getItem("peopleList"))
  }

  peopleList.push({
    
    medicine_name : medicine_name,
    batchNo : batchNo,
    mfg : mfg,
    exp : exp,
    qty2 : qty2,
    total : total,
  });

  localStorage.setItem("peopleList", JSON.stringify(peopleList));
  showData();
  document.getElementById("medicine_id").value = "";
  document.getElementById("medicine_name").value = "";
  document.getElementById("batchNo").value = "";
  document.getElementById("mfg").value = "";
  document.getElementById("exp").value = "";
  document.getElementById("qty2").value = "";
  document.getElementById("total").value = "";



  }
}

 $(function () {
        $("#btnDelete").click(function () {
            $("#crudTable").find("tr:not(:first)").remove();
        });
    });