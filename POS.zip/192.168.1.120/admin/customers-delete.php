<?php 

require '../config/function.php';

$paraResultId = checkParamId('id');

if(is_numeric($paraResultId)){

	$customerId = validate($paraResultId);

	$customers = getById('customers',$customerId);
	if($customers['status'] == 200)
	{
		$customerDeleteRes = delete('customers', $customerId);
		if($customerDeleteRes)
		{
			redirect('customers.php','Customer Deleted Successfully !!!');
		}
		else
		{
			redirect('customers.php','Something Went Wrong !!!');
		}

	}
	else
	{
	redirect('customers.php',$customers['message']);	
	}

	// echo $adminId;


}else{
	http_redirect('customers.php','Something Went Wrong !!!');

}

 ?>