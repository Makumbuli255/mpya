<?php 
include ('../config/function.php');

if(!isset($_SESSION['medicineItems'])){
	$_SESSION['medicineItems'] = [];

}

if(!isset($_SESSION['medicineItemIds'])){
	$_SESSION['medicineItemIds'] = [];

}

if(isset($_POST['addItem']))
{
	$medicineId = validate($_POST['medicine_id']);
	$quantity = validate($_POST['quantity']);

	$checkMedicine = mysqli_query($conn, "SELECT * FROM medicine WHERE id='$medicineId' LIMIT 1");
	if($checkMedicine){

		if(mysqli_num_rows($checkMedicine) > 0){

			$row = mysqli_fetch_assoc($checkMedicine);
			if($row['quantity'] < $quantity){
				redirect('order-create.php', 'Only' .$row['quantity']. 'quantity available!');

			}

			$medicineData = [
				'medicine_id' => $row['id'],
				'name' => $row['name'],
			    'batch' => $row['batch'],
			    'mfg' => $row['mfg'],
			    'exp' => $row['exp'],
			    'quantity' => $quantity,
			    'price' => $row['price'],
			];

			if(!in_array($row['id'], $_SESSION['medicineItemIds'])){

				array_push($_SESSION['medicineItemIds'],$row['id']);
			    array_push($_SESSION['medicineItems'],$medicineData);

			}else{
				foreach ($_SESSION['medicineItems'] as $key => $medicineSessionItem) {
					if($medicineSessionItem['medicine_id'] == $row['id']){

						$newQuantity = $medicineSessionItem['quantity'] + $quantity;

		$medicineData = [
				'medicine_id' => $row['id'],
				'name' => $row['name'],
			    'batch' => $row['batch'],
			    'mfg' => $row['mfg'],
			    'exp' => $row['exp'],
			    'quantity' => $newQuantity,
			    'price' => $row['price'],
			];
			$_SESSION['medicineItems'][$key] = $medicineData;
			}
		}

	}

	redirect('order-create.php', 'Medicine Added '.$row['name']);

		}else{
			redirect('order-create.php', 'No such Medicine Found!');
		}

	}else{
		redirect('order-create.php', 'Something Went Wrong!');
	}

}

if (isset($_POST['medicineIncDec'])) 
{
	$medicineId = validate($_POST['medicine_id']);
	$quantity = validate($_POST['quantity']);

	$flag = false;
	foreach ($_SESSION['medicineItems'] as $key => $item) {
		if($item['medicine_id'] == $medicineId){
    
            $flag = true;
			$_SESSION['medicineItems'][$key]['quantity'] = $quantity;

		}
	}

	if($flag){

		jsonResponse(200, 'success', 'Quantity Updated');
	}else{

		jsonResponse(500, 'error', 'Something Went Wrong. Please Refresh');
	}

}

if (isset($_POST['proceedToPlaceBtn'])) 
{
	$phone = validate($_POST['cphone']);
	$payment_mode = validate($_POST['payment_mode']);

	
	$checkCustomer = mysqli_query($conn, "SELECT * FROM customers WHERE phone='$phone' LIMIT 1");
	if($checkCustomer){
        if (mysqli_num_rows($checkCustomer) > 0) 
        {
        	$_SESSION['invoice_no'] = "INV-MSP".rand(111111,999999);
        	$_SESSION['cphone'] = $phone;
        	$_SESSION['payment_mode'] = $payment_mode;
        	jsonResponse(200, 'success', 'Customer Found');
        }
        else
        {
        	$_SESSION['cphone'] = $phone;
        	jsonResponse(404, 'warning', 'Customer Not Found');
        }
	}
	else
	{
		jsonResponse(500, 'error', 'Something Went Wrong');
	}
}


if (isset($_POST['saveCustomerBtn'])) 
{
	$name = validate($_POST['name']);
	$phone = validate($_POST['phone']);
	$email = validate($_POST['email']);
	$location = validate($_POST['location']);

	if ($name != '' && $phone != '' && $location != '') {

		$data = [
			'name' => $name,
			'phone' => $phone,
			'email' => $email,
			'location' => $location,

		];
		$result = insert('customers', $data);
		if ($result) {
			jsonResponse(200, 'success', 'Customer Created Successfully');
		}else{
			jsonResponse(500, 'error', 'Something Went Wrong');
		}

	}else{
		jsonResponse(422, 'warning', 'Please fill required fields');
	}

}


if (isset($_POST['saveOrder'])) 
{
	$phone = validate($_SESSION['cphone']);
	$invoice_no = validate($_SESSION['invoice_no']);
	$payment_mode = validate($_SESSION['payment_mode']);
	$order_placed_by_id = $_SESSION['loggedInUser']['user_id'];

	$checkCustomer = mysqli_query($conn, "SELECT * FROM customers WHERE phone='$phone' LIMIT 1");
	if (!$checkCustomer) {
		jsonResponse(500, 'error', 'Something Went Wrong!');
	}

	if (mysqli_num_rows($checkCustomer) > 0) 
	{
		$customerData = mysqli_fetch_assoc($checkCustomer);

        if (!isset($_SESSION['medicineItems'])) {
        	jsonResponse(404,'warning', 'No Items to place order!');
        }

        $sessionMedicine = $_SESSION['medicineItems'];

        $totalAmount = 0;
        foreach ($sessionMedicine as $amtItem) {
        	$totalAmount += $amtItem['price'] * $amtItem['quantity'];
        }

        $data = [
        	'customer_id' => $customerData['id'],
        	'tracking_no' => rand(11111,99999),
        	'invoice_no' => $invoice_no,
        	'total_amount' => $totalAmount,
        	'order_date' => date('Y-m-d'),
        	'order_status' => 'ordered',
        	'payment_mode' => $payment_mode,
        	'order_placed_by_id' => $order_placed_by_id,
        ];
        $result = insert('orders', $data);
        $lastOrderId = mysqli_insert_id($conn);

        foreach ($sessionMedicine as $medItem) {

        	$medicineId = $medItem['medicine_id'];
        	$price = $medItem['price'];
        	$quantity = $medItem['quantity'];

        	// Inserting order items
        	$dataOrderItem = [
        		'order_id' => $lastOrderId,
        		'medicine_id' => $medicineId,
        		'price' => $price,
        		'quantity' => $quantity,
        	];
        	$orderItemQuery = insert('order_items', $dataOrderItem);

        	// check and decleasing quantity and making total quantity
        $checkMedicineQuantityQuery = mysqli_query($conn, "SELECT * FROM medicine WHERE id='$medicineId'");
        	$medicineQtyData = mysqli_fetch_assoc($checkMedicineQuantityQuery);
        	$totalMedicineQuantity = $medicineQtyData['quantity'] - $quantity;

        	$dataUpdate = [
        		'quantity' => $totalMedicineQuantity
        	];
        	$updateMedicineQty = update('medicine', $medicineId, $dataUpdate);
        }

        unset($_SESSION['medicineItemIds']);
        unset($_SESSION['medicineItems']);
        unset($_SESSION['cphone']);
        unset($_SESSION['payment_mode']);
        unset($_SESSION['invoice_no']);

        jsonResponse(200, 'success', 'Order Placed Successfully');
	}
	else
	{
        jsonResponse(404, 'warning', 'No Customer Found!');
	}
	
}


 ?>