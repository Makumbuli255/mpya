<?php 

include ('../config/function.php');

if (isset($_POST['saveAdmin'])) 
{
	# code...
	$name = validate($_POST['name']);
	$email = validate($_POST['email']);
	$password = validate($_POST['password']);
	$phone = validate($_POST['phone']);
	$is_ban = isset($_POST['is_ban']) == true ? 1:0;

	if ($name != '' && $email != '' && $password != '') {
		# code...
		$emailCheck = mysqli_query($conn, "SELECT * FROM admins WHERE email='$email'");
		if ($emailCheck) {
			# code...
			if (mysqli_num_rows($emailCheck) > 0) {
				# code...
				redirect('admins-create.php','Email Already Used by another User.');

			}
		}

		$bcrypt_password = password_hash($password, PASSWORD_BCRYPT);

		$data = [
			'name' => $name,
			'email' => $email,
			'password' => $bcrypt_password,
			'phone' => $phone,
			'is_ban' => $is_ban

		];
		$result = insert('admins',$data);
		if ($result) {
			# code...
			redirect('admins.php','Admin Created Successfully.');

		}else{
			redirect('admins-create.php','Something Went Wrong.');
		}


	}else{
		redirect('admins-create.php','Please fill required fields.');
	}
}
 if (isset($_POST['updateAdmin'])) 
 {
 	# code...
 	$adminId = validate($_POST['adminId']);

 	$adminData = getById('admins', $adminId);
 	if($adminData['status'] != 200){
 		redirect('admins-edit.php?id='.$adminId,'Please fill required fields.');

 	}


 	$name = validate($_POST['name']);
	$email = validate($_POST['email']);
	$password = validate($_POST['password']);
	$phone = validate($_POST['phone']);
	$is_ban = isset($_POST['is_ban']) == true ? 1:0;

	$EmailCheckQuery = "SELECT * FROM admins WHERE email='$email' AND id!='$adminId'";
	$checkResult = mysqli_query($conn, $EmailCheckQuery);
	if($checkResult){
		if(mysqli_num_rows($checkResult) > 0){
			redirect('admins-edit.php?id='.$adminId,'Email Already Used by another User');
		}
	}

	if($password != ''){
		$hashedPassword = password_hash($password, PASSWORD_BCRYPT);

	}else{
        $hashedPassword = $adminData['data']['password'];
	}

	if ($name != '' && $email != '') 
	{
		$data = [
			'name' => $name,
			'email' => $email,
			'password' => $hashedPassword,
			'phone' => $phone,
			'is_ban' => $is_ban

		];
		$result = update('admins', $adminId, $data);

		if ($result) {
			# code...
			redirect('admins-edit.php?id='.$adminId,'Admin Updated Successfully.');

		}else{
			redirect('admins-edit.php?id='.$adminId,'Something Went Wrong.');
		}

	}
	else{
		redirect('admins-create.php','Please fill required fields.');
	}

 }


if (isset($_POST['saveCategory'])) {
	# code...
	$name = validate($_POST['name']);
	$description = validate($_POST['description']);
	$status = isset($_POST['status']) == true ? 1:0;

	$data = [
			'name' => $name,
			'description' => $description,
			'status' => $status

		];
		$result = insert('categories',$data);
		if ($result) {
			# code...
			redirect('categories.php','Category Created Successfully.');

		}else{
			redirect('categories-create.php','Something Went Wrong.');
		}

}

if(isset($_POST['updateCategory']))
{
	$categoryId = validate($_POST['categoryId']);
	$name = validate($_POST['name']);
	$description = validate($_POST['description']);
	$status = isset($_POST['status']) == true ? 1:0;

	$data = [
			'name' => $name,
			'description' => $description,
			'status' => $status

		];
		$result = update('categories', $categoryId, $data);
		if ($result) {
			# code...
			redirect('categories-edit.php?id='.$categoryId,'Category Updated Successfully.');

		}else{
			redirect('categories-edit.php?id='.$categoryId,'Something Went Wrong.');
		}

}

if(isset($_POST['saveMedicine']))
{
	$category_id = validate($_POST['category_id']);
	$name = validate($_POST['name']);
	$batch = validate($_POST['batch']);
	$mfg = validate($_POST['mfg']);
	$exp = validate($_POST['exp']);
	$quantity = validate($_POST['quantity']);
	$buy = validate($_POST['buy']);
	$price = validate($_POST['price']);
	$status = isset($_POST['status']) == true ? 1:0;

	$data = [
		    'category_id' => $category_id,
			'name' => $name,
			'batch' => $batch,
			'mfg' => $mfg,
			'exp' => $exp,
			'quantity' => $quantity,
			'buy' => $buy,
			'price' => $price,
			'status' => $status

		];
		$result = insert('medicine',$data);
		if ($result) {
			# code...
			redirect('medicine.php','Product Created Successfully.');

		}else{
			redirect('medicine-create.php','Something Went Wrong.');
		}

}

if(isset($_POST['updateMedicine']))
{
	$medicineId = validate($_POST['medicineId']);
	$name = validate($_POST['name']);
	$batch = validate($_POST['batch']);
	$mfg = validate($_POST['mfg']);
	$exp = validate($_POST['exp']);
	$quantity = validate($_POST['quantity']);
	$buy = validate($_POST['buy']);
	$price = validate($_POST['price']);
	$status = isset($_POST['status']) == true ? 1:0;

	$data = [
			'name' => $name,
			'batch' => $batch,
			'mfg' => $mfg,
			'exp' => $exp,
			'quantity' => $quantity,
			'buy' => $buy,
			'price' => $price,
			'status' => $status

		];
		$result = update('medicine', $medicineId, $data);
		if ($result) {
			# code...
			redirect('medicine-edit.php?id='.$medicineId,'Product Updated Successfully.');

		}else{
			redirect('medicine-edit.php?id='.$medicineId,'Something Went Wrong.');
		}
}

// customer
if (isset($_POST['saveCustomer'])) 
{
	# code...
	$name = validate($_POST['name']);
	$email = validate($_POST['email']);
	$location = validate($_POST['location']);
	$phone = validate($_POST['phone']);
	$is_ban = isset($_POST['is_ban']) == true ? 1:0;

	if ($name != '' && $email != '') {
		# code...
		$emailCheck = mysqli_query($conn, "SELECT * FROM customers WHERE email='$email'");
		if ($emailCheck) {
			# code...
			if (mysqli_num_rows($emailCheck) > 0) {
				# code...
				redirect('customers-create.php','Email Already Used by another User.');

			}
		}


		$data = [
			'name' => $name,
			'email' => $email,
			'location' => $location,
			'phone' => $phone,
			'status' => $status

		];
		$result = insert('customers',$data);
		if ($result) {
			# code...
			redirect('customers.php','Customer Created Successfully.');

		}else{
			redirect('customers-create.php','Something Went Wrong.');
		}


	}else{
		redirect('customers-create.php','Please fill required fields.');
	}
}
 if (isset($_POST['updateCustomer'])) 
 {
 	# code...
 	$customerId = validate($_POST['customerId']);

 	$customerData = getById('customers', $customerId);
 	if($customerData['status'] != 200){
 		redirect('customers-edit.php?id='.$customerId,'Please fill required fields.');

 	}


 	$name = validate($_POST['name']);
	$email = validate($_POST['email']);
	$location = validate($_POST['location']);
	$phone = validate($_POST['phone']);
	$is_ban = isset($_POST['is_ban']) == true ? 1:0;

	$EmailCheckQuery = "SELECT * FROM customers WHERE email='$email' AND id!='$customerId'";
	$checkResult = mysqli_query($conn, $EmailCheckQuery);
	if($checkResult){
		if(mysqli_num_rows($checkResult) > 0){
			redirect('customers-edit.php?id='.$customerId,'Email Already Used by another Customer');
		}
	}


	if ($name != '' && $email != '') 
	{
		$data = [
			'name' => $name,
			'email' => $email,
			'location' => $location,
			'phone' => $phone,
			'status' => $status

		];
		$result = update('customers', $customerId, $data);

		if ($result) {
			# code...
			redirect('customers-edit.php?id='.$customerId,'Customer Updated Successfully.');

		}else{
			redirect('customers-edit.php?id='.$customerId,'Something Went Wrong.');
		}

	}
	else{
		redirect('customers-create.php','Please fill required fields.');
	}

 }


 // SETTING
 if (isset($_POST['saveSetting'])) {
	# code...
	$names = validate($_POST['names']);
	$phone = validate($_POST['phone']);
	$po_address = validate($_POST['po_address']);
	$ph_address = validate($_POST['ph_address']);

	
		$nameCheck = mysqli_query($conn, "SELECT * FROM setting");
		if ($nameCheck) {
			# code...
	
	

	$data = [
			'names' => $names,
			'phone' => $phone,
			'po_address' => $po_address,
			'ph_address' => $ph_address
			

		];
		$result = insert('setting',$data);
		if ($result) {
			# code...
			redirect('setting.php','Setting Created Successfully.');

		}else{
			redirect('setting-create.php','Something Went Wrong.');
		}

}}

if(isset($_POST['updateSetting']))
{
	$settingId = validate($_POST['settingId']);
	$names = validate($_POST['names']);
	$phone = validate($_POST['phone']);
	$po_address = validate($_POST['po_address']);
	$ph_address = validate($_POST['ph_address']);
	

	$data = [
			'names' => $names,
			'phone' => $phone,
			'po_address' => $po_address,
			'ph_address' => $ph_address

		];
		$result = update('setting', $settingId, $data);
		if ($result) {
			# code...
			redirect('categories-edit.php?id='.$settingId,'Settings Updated Successfully.');

		}else{
			redirect('categories-edit.php?id='.$settingId,'Something Went Wrong.');
		}

}


 ?>