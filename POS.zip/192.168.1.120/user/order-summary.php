<?php 
include ('includes/header.php'); 

if (!isset($_SESSION['medicineItems'])) {
	echo '<script> window.location.href = "order-create.php"; </script>';
}

?>


<br>
<div class="container-fluid px-4">
	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-header">
					<h3 class="mb-2 text-success text-center">Sccessfully sent To Cashier
						<a href="order-create.php" class="btn btn-danger float-end">Back to create order</a>
					</h3>
				</div>

			</div>
		</div>
	</div>
</div>
<?php include ('includes/footer.php'); ?>