<?php include ('includes/header.php'); ?>

<div class="container-fluid px-4">
	<div class="card mt-4 shadow-sm">
		<div class="card-header">
			<h4 class="mb-0">Product
				<a href="medicine-create.php" class="btn btn-primary float-end">Add Product</a></h4>
		</div>
		<div class="card-body">
			<?php alertMessage(); ?>

			<?php
				$medicine  = getAll('medicine');
				if(!$medicine){
                   echo '<h4>Something Went Wrong!</h4>';
                   return false;

				} 
				if(mysqli_num_rows($medicine) > 0)
				{

	    	 ?>
			<div class="table-responsive">
				<table class="table table-striped table-bordered">
					<thead>
						<tr>
							<th>ID</th>
							<th>Product Name</th>
                            <th>Batch No</th>
                            <th>Exp Date</th>
                            <th>Quantity</th>
                            <th>Condition</th>
							<th>Status</th>
							<th>Action</th>
						</tr>
					</thead>

					<tbody>
						
						 <?php foreach ($medicine as $item) : ?>
						<tr>
							<td><?= $item['id'] ?></td>
							<td><?= $item['name'] ?></td>
							<td><?= $item['batch'] ?></td>
							<td><?= $item['exp'] ?></td>
							<td><?= $item['quantity'] ?></td>
							<td>
              <?php 
                  $expires_at = new DateTime($item['exp']);
                  $today      = new DateTime('now');

                  if($expires_at < $today)
                  echo '<h6 class="text-danger">Expired</h6>';
                elseif ($expires_at > $today) 
                  echo '<h6 class="text-success">Active</h6>';

                   ?>


                    
            </td>
							<td>
								<?php
								if($item['status'] == 1){
									echo '<span class="badge bg-danger">Not Available</span>';
								}else{
									echo '<span class="badge bg-primary">Available</span>';
								} 

								 ?>
							</td>
							<td>
								<a href="medicine-edit.php?id=<?= $item['id']; ?>" class="btn btn-success btn-sm">Edit</a>
							</td>
						</tr>
					<?php endforeach; ?>
					
					</tbody>
					
				</table>
				
			</div>
			<?php 
				}
				else
				{
			?>
				<tr>
					<h4 class="mb-0">No Record found</h4>
				</tr>
			<?php
				}
			?>
			
		</div>
	</div>
		
</div>

<?php include ('includes/footer.php'); ?>